(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();

function validateForm() {
    // Get form fields
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const email = document.getElementById('email').value;
    const dob = new Date(document.getElementById('dob').value);

    // Regex patterns
    const namePattern = /^[a-zA-Z ]*$/; // Only letters and spaces allowed
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Simple email validation

    // Validate First Name
    if (!namePattern.test(firstName)) {
        document.getElementById('firstName').classList.add('is-invalid');
        return false;
    } else {
        document.getElementById('firstName').classList.remove('is-invalid');
    }

    // Validate Last Name
    if (!namePattern.test(lastName)) {
        document.getElementById('lastName').classList.add('is-invalid');
        return false;
    } else {
        document.getElementById('lastName').classList.remove('is-invalid');
    }

    // Validate Email
    if (!emailPattern.test(email)) {
        document.getElementById('email').classList.add('is-invalid');
        return false;
    } else {
        document.getElementById('email').classList.remove('is-invalid');
    }

    // Validate DOB
    const today = new Date();
    const birthDate = new Date(dob);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }

    if (age < 16 || age > 80) {
        document.getElementById('dob').classList.add('is-invalid');
        return false;
    } else {
        document.getElementById('dob').classList.remove('is-invalid');
    }

    // If all validations pass, return true to submit the form
    return true;
}


// Attach event listener to form on submit
document.getElementById('employeeForm').addEventListener('submit', function(event) {
    if (!validateForm()) {
        event.preventDefault();
        event.stopPropagation();
    }
});

// Attach event listener to form on submit
document.getElementById('employeeForm').addEventListener('submit', function(event) {
    if (!validateForm()) {
        event.preventDefault();
    }
});