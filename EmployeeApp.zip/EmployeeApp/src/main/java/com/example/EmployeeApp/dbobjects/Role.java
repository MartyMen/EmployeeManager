package com.example.EmployeeApp.dbobjects;

public enum Role {
    ROLE_USER,
    ADMIN
}
